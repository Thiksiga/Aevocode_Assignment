#include <stdio.h>
#include <stdint.h>  // For fixed-width integer types
#include <unistd.h>  // For usleep

// AXI Register Addresses (adjust based on your system's memory map)
#define RPM_REGISTER_ADDR        0x40000008  // Address of RPM register in FPGA
#define PWM_PERIOD_REGISTER_ADDR 0x40000000  // Address of PWM period register in FPGA
#define PWM_DUTY_REGISTER_ADDR   0x40000004  // Address of PWM duty cycle register in FPGA

// PID Controller structure definition
typedef struct {
    double kp;              // Proportional gain
    double ki;              // Integral gain
    double kd;              // Derivative gain
    double prev_err;        // Previous error value for derivative calculation
    double integral_acc;    // Integral accumulator for integral calculation
} PID;

// Function to initialize PID controller
void initialize_pid(PID *controller, double proportional_gain, double integral_gain, double derivative_gain) {
    controller->kp = proportional_gain;
    controller->ki = integral_gain;
    controller->kd = derivative_gain;
    controller->prev_err = 0.0;
    controller->integral_acc = 0.0;
}

// Function to calculate the control value from the PID controller
double calculate_pid_output(PID *controller, double target_value, double current_value, double dt) {
    double error = target_value - current_value;
    controller->integral_acc += error * dt;
    double derivative = (error - controller->prev_err) / dt;
    controller->prev_err = error;

    // Compute the PID control output
    double control_output = (controller->kp * error) + (controller->ki * controller->integral_acc) + (controller->kd * derivative);
    return control_output;
}

// Function to read RPM from the FPGA (AXI register)
uint32_t read_rpm() {
    return *(volatile uint32_t *)(RPM_REGISTER_ADDR);
}

// Function to write PWM period to the FPGA (AXI register)
void write_pwm_period(uint32_t period) {
    *(volatile uint32_t *)(PWM_PERIOD_REGISTER_ADDR) = period;
}

// Function to write PWM duty cycle to the FPGA (AXI register)
void write_pwm_duty(uint32_t duty) {
    *(volatile uint32_t *)(PWM_DUTY_REGISTER_ADDR) = duty;
}

int main() {
    // Define a PID controller object
    PID motor_pid;

    // Target RPM value and the measured RPM from the motor
    double target_rpm = 5000.0;
    double current_rpm;

    // Time delta (loop interval in seconds)
    double delta_time = 0.01;  // 10ms control loop
    double pid_output;

    // Fixed 10kHz PWM period (100 microseconds)
    uint32_t pwm_period = 100;
    uint32_t pwm_duty_cycle;

    // Initialize the PID controller (adjust tuning parameters as needed)
    initialize_pid(&motor_pid, 1.0, 0.1, 0.01);

    // Write the PWM period to the FPGA (this remains fixed)
    write_pwm_period(pwm_period);

    // Control loop for testing
    for (int step = 0; step < 2000; step++) {  // Simulate over 20 seconds
        // Read the current motor RPM from the FPGA register
        current_rpm = (double)read_rpm();

        // Compute the PID controller output based on the current RPM and target RPM
        pid_output = calculate_pid_output(&motor_pid, target_rpm, current_rpm, delta_time);

        // Convert PID output to PWM duty cycle percentage (0 to 100%)
        if (pid_output < 0) pid_output = 0;           // Limit the output to a minimum of 0%
        if (pid_output > 100) pid_output = 100;       // Limit the output to a maximum of 100%

        // Calculate the PWM duty cycle based on the output
        pwm_duty_cycle = (uint32_t)((pid_output / 100.0) * pwm_period);

        // Write the calculated PWM duty cycle to the FPGA
        write_pwm_duty(pwm_duty_cycle);

        // Display the results for this time step
        printf("Step: %d | Current RPM: %.2f | Target RPM: %.2f | PID Output: %.2f | PWM Duty Cycle: %u%%\n", 
               step, current_rpm, target_rpm, pid_output, pwm_duty_cycle);

        // Simulate the control loop delay (10ms)
        usleep((int)(delta_time * 1000000));  // Sleep for delta_time seconds in microseconds
    }

    return 0;
}

